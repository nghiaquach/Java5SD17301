package com.fpoly.model;

public interface Speech {
    public String sayThankYou();
}
